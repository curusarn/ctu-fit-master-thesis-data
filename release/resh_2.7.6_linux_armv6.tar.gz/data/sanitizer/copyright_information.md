# copyright information

Whitelist contains content from variety of sources.

Part of the whitelist (`./whitelist.txt`) is made of copyrighted content from [FileInfo.com](https://fileinfo.com/filetypes/common).

This content was used with permission from FileInfo.com.
